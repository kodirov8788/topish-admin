import React, { useState } from 'react'

function Test({ setRight, right, data, ans, setAns, setCount, count, setWrong, wrong }) {
    console.log(ans)

    const FormFunction = (e) => {
        e.preventDefault()

        if (ans === "") {
            alert("joylarni to'ldiring")
        } else {
            console.log(ans == data.answer)
            if (ans != data.answer) {
                setWrong(wrong + 1)

            } else {
                setRight(right + 1)
            }
            if (wrong === 3) {
                alert("siz yiqildingiz")
            } else {
                setCount(count + 1)
            }
        }
        setAns("")
    }


    return (
        <div>
            <form onSubmit={FormFunction} className="card">
                <img src={data.flag} alt="" />
                <div className="donate-now" onChange={e => setAns(e.target.value)}>
                    {data.options.map((el, inx) => (
                        <li>
                            <input defaultChecked={false} type="radio" value={el} name="amount" />
                            <label for={el}>{el}</label>
                        </li>
                    ))}

                </div>

                <button>Jo'natish</button>
            </form>
        </div>
    )
}

export default Test